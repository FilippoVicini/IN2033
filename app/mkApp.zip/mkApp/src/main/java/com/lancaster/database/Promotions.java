package com.lancaster.database;

import java.time.LocalDateTime;
import java.util.List;

/**
 * Class handling promotional data for Lancaster's Music Hall Box Office
 */
public class Promotions {

    /**
     * Inner class containing details about a specific promotion
     */
    public static class PromotionDetails {

    }

    /**
     * Inner class containing statistics about promotion performance
     */
    public static class PromotionStats {
    }
}
